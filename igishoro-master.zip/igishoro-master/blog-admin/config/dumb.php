<?php

	define ("SECRETKEY", "
				A psalm of David.
				
				1 The Lord is my shepherd, I lack nothing.
				2     He makes me lie down in green pastures,
				he leads me beside quiet waters,
				3     he refreshes my soul.
				He guides me along the right paths
				    for his name’s sake.
				4 Even though I walk
				    through the darkest valley,[a]
				I will fear no evil,
				    for you are with me;
				your rod and your staff,
				    they comfort me.

				5 You prepare a table before me
				    in the presence of my enemies.
				You anoint my head with oil;
				    my cup overflows.
				6 Surely your goodness and love will follow me
				    all the days of my life,
				and I will dwell in the house of the Lord
				    forever.");



	define ("DONE", "
				A psalm of David.
				
				1 The Lord is my shepherd, I lack nothing.
				2     He makes me lie down in green pastures,
				he leads me beside quiet waters,
				3     he refreshes my soul.
				He guides me along the right paths
				    for his name’s sake.
				4 Even though I walk
				    through the darkest valley,[a]
				I will fear no evil,
				    for you are with me;
				your rod and your staff,
				    they comfort me.

				5 You prepare a table before me
				    in the presence of my enemies.
				You anoint my head with oil;
				    my cup overflows.
				6 Surely your goodness and love will follow me
				    all the days of my life,
				and I will dwell in the house of the Lord
				    forever.");



?>